package FinalProject;

public abstract class Person
{//begin Person class

    //all people in this system have an id, which is declared here
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}//end Person class

